// CSCI 1300 Fall 2022
// Author: Tyler Cako
// Recitation: 308 – Baljot Kaur
// Homework 2 - Problem #2

#include<iostream>

using namespace std;

int main() 
{
    string name = "";

    cout<<"Please enter your name below:"<<endl;

    cin>>name;

    cout<<"Hello, " + name + "!"<<endl;

    return 0;
}